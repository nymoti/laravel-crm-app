"use strict";

$(document).ready(function() {

    /* initialize the external events
     -----------------------------------------------------------------*/
    function ini_events(ele) {
        ele.each(function () {

            // create an Event Object (http://arshaw.com/fullcalendar/docs/event_data/Event_Object/)
            // it doesn't need to have a start or end
            var eventObject = {
                title: $.trim($(this).text()) // use the element's text as the event title
            };

            // store the Event Object in the DOM element so we can get to it later
            $(this).data('eventObject', eventObject);

            // make the event draggable using jQuery UI
            $(this).draggable({
                zIndex: 1070,
                revert: true, // will cause the event to go back to its
                revertDuration: 0 //  original position after the drag
            });

        });
    }

    ini_events($('#external-events').find('div.external-event'));

    /* initialize the calendar
     -----------------------------------------------------------------*/
    //Date for the calendar events (dummy data)
    var date = new Date();
    var d = date.getDate(),
        m = date.getMonth(),
        y = date.getFullYear();
    $('#calendar').fullCalendar({
        header: {
            left: 'prev,next today',
            center: 'title',
            right: 'month,agendaWeek,agendaDay'
        },
        buttonText: {

            today: 'today',
            month: 'month',
            week: 'week',
            day: 'day'
        },
        //Random events
        events: '/get-recalls',
        editable: true,
        // droppable: false, // this allows things to be dropped onto the calendar !!!
        // draggable: false,
        revert: true,      // immediately snap back to original position
        revertDuration: 0  ,//

        eventLimitText: "Plus", // Default is `more` (or "more" in the lang you pick in the option)
        eventLimit: true, // for all non-agenda views 
        displayEventTime: false, // hide fc time
        drop: function (date, allDay) { // this function is called when something is dropped

            // retrieve the dropped element's stored Event Object
            var originalEventObject = $(this).data('eventObject');

            // we need to copy it, so that multiple events don't have a reference to the same object
            var copiedEventObject = $.extend({}, originalEventObject);

            // assign it the date that was reported
            copiedEventObject.start = date;
            copiedEventObject.allDay = allDay;
            copiedEventObject.backgroundColor = $(this).css("background-color");
            copiedEventObject.borderColor = $(this).css("border-color");

            // render the event on the calendar
            // the last `true` argument determines if the event "sticks" (http://arshaw.com/fullcalendar/docs/event_rendering/renderEvent/)
            $('#calendar').fullCalendar('renderEvent', copiedEventObject, true);
            $(".badge1").text(parseInt($(".badge1").text()) + 1);
            // is the "remove after drop" checkbox checked?
            if ($('#drop-remove').is(':checked')) {
                // if so, remove the element from the "Draggable Events" list
                $(this).remove();
            }

        },
        eventClick: function(event) { 
            console.log(event); 
            $('#recallDetails').modal('show');     

            $("#full-nameD").val(event.title);
            $("#recall-id").val(event.id); 
            $("#recall-colorD").val(event.backgroundColor);
            $("#addressD").val(event.address);
            $("#telD").val(event.tel); 
            $("#start-dateD").val('');
            $("#start-dateD").val(moment(event.start).format("YYYY-MM-DD"));
            $("#hourD").val(event.hour); 
            $('#eventTitle').val(event.title);  
            $('#eventBackgroundColor').css({
             "background-color": event.backgroundColor,
            });
            $('#descriptionD').val(event.description);
            $('#recallColor').val('');

            $('#recallColor').val(event.backgroundColor); 

 
            var recallColor = $('#recallColor').val();
            var primaryColor = $('#primaryColor');
            var successColor = $('#successColor');
            var infoColor = $('#infoColor');
            var warningColor = $('#warningColor');
            var dangerColor = $('#dangerColor');
            var defaultColor = $('#defaultColor');  

            if(event.backgroundColor == primaryColor.css("background-color")){ 
                $('#select_color option[name="primaryColor"]').prop('selected', true); 
                $('#select_color').css("background-color", event.backgroundColor);  
            }else if(event.backgroundColor == successColor.css("background-color")){
                $('#select_color option[name="successColor"]').prop('selected', true);
                $('#select_color').css("background-color", event.backgroundColor);

            }else if(event.backgroundColor == infoColor.css("background-color")){
                $('#select_color option[name="infoColor"]').prop('selected', true);
                $('#select_color').css("background-color", event.backgroundColor);

            }else if(event.backgroundColor == warningColor.css("background-color")){
                $('#select_color option[name="warningColor"]').prop('selected', true); 
                $('#select_color').css("background-color", event.backgroundColor);

            }else if(event.backgroundColor == defaultColor.css("background-color")){
                $('#select_color option[name="defaultColor"]').prop('selected', true); 
                $('#select_color').css("background-color", event.backgroundColor);

            }else if(event.backgroundColor == dangerColor.css("background-color")){
                $('#select_color option[name="dangerColor"]').prop('selected', true); 
                // $('#select_color').addClass('palette-danger');
                $('#select_color').css("background-color", event.backgroundColor);

            }
            var recallOldColor = $('#select_color').css("background-color");
            console.log(recallOldColor);
       }
       // ,eventRender: function(event) { 
       //     console.log(event);           
       //  }
  
    }); 


    $('#select_color').change(function(e){
        e.preventDefault();
        var selecteOptionBgColor = $('#select_color').find(":selected").css("background-color");
        $('#select_color').css("background-color", selecteOptionBgColor);
        $('#recallColor').val(selecteOptionBgColor) ;
    });


    /* ADDING EVENTS */
    var currColor = "rgb(79, 193, 233)"; //default
    //Color chooser button
    var colorChooser = $("#color-chooser-btn");
    $("#color-chooser").find('li > a').on('click', function (e) {
        e.preventDefault();
        //Save color
        currColor = $(this).css("background-color");
        //Add color effect to button
        colorChooser
            .css({
                "background-color": currColor,
                "border-color": currColor
            })
            .html($(this).text() + ' <span class="caret"></span>');
        $('#recall-color').val(currColor);
    }); 
    
   
    
    $("#add-new-recall").on('click', function (e) {
        e.preventDefault();      
        var fullName = $("#full-name").val();
        var recallColor = currColor;
        var address = $("#address").val();
        var tel = $("#tel").val(); 
        var startDate = $("#start-date").val();
        var hour = $("#hour").val();   
        var userId = $("#user-id").val(); 
        var description = $('#description').val();
        if(startDate != ''){ 
            Command: toastr["warning"]("Veuillez attendre...", "Ajouter Agenda") 
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });      
            $.ajax({
                type:"POST",
                url:"/create-recalls",
                data :  {
                    "created_by": userId,
                    "full_name": fullName,
                    "address": address,
                    "tel": tel,
                    "start_date": startDate,
                    "hour": hour,
                    "color": recallColor,
                    "description": description
                },
                datatype:"html",
                success:function(data) {  
                    // console.log(data); 
                    var recall = { 
                        id: data.id ,
                        title: data.full_name,
                        start: data.start_date, 
                        backgroundColor: data.color,
                        tel: data.tel,
                        hour: data.hour,
                        address: data.ddress ,
                        description: data.description
                    }                
                    Command: toastr["success"]("L'agenda a étè ajouté avec succès !", "Ajouter Agenda");    
                    $('#calendar').fullCalendar( 'renderEvent', recall, true); // add new  recall  to DOM
                    $('#addNewRecall').hide();
                    $("#full-name").val('');
                    $("#address").val('');
                    $("#tel").val(''); 
                    $("#start-date").val('');
                    $("#hour").val(''); 
                    $('#description').val('');
                }
            }); 

        toastr.options = {
            "closeButton": true,
            "debug": false,
            "newestOnTop": false,
            "progressBar": true,
            "positionClass": "toast-top-right",
            "preventDuplicates": false,
            "onclick": null,
            "showDuration": "1000",
            "hideDuration": "1000",
            "timeOut": "3000",
            "extendedTimeOut": "1000",
            "showEasing": "swing",
            "hideEasing": "swing",
            "showMethod": "show"
            } 
        } else {
            // console.log('not valid');
            $('#addressMessage').text('La date est obligatoire !');
            $("#start-date").focus();
            setTimeout(function() {
                $("#dateMessage").text('');                       
            }, 3000);
        }            
    });


    $("#update-recall").on('click', function (e) {
        e.preventDefault();         
        var recallId = $("#recall-id").val();
        var fullName = $("#full-nameD").val(); 
        var address = $("#addressD").val();
        var tel = $("#telD").val(); 
        var startDate = $("#start-dateD").val();
        var hour = $("#hourD").val();     
        var backColor = $("#recall-colorD").val();
        var description = $('#descriptionD').val();
        var recallColor = $('#recallColor').val();
        // console.log(`${fullName} ${recallColor} ${address} ${tel} ${startDate} ${hour} ${userId}`);
        // create new recall  

        if(startDate != ''){
            // console.log('valid') ;
            Command: toastr["warning"]("Veuillez attendre...", "Modifier Agenda") 
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });      
            $.ajax({
                type:"PUT",
                url:"/update-recall",
                data :  {
                    "id": recallId, 
                    "full_name": fullName,
                    "address": address,
                    "tel": tel,
                    "start_date": startDate,
                    "hour": hour ,
                    "description": description,
                    "color" : recallColor 
                },
                datatype:"html",
                success:function(data) {  
                    console.log(data); 
                    var recall = { 
                        id: data.id ,
                        title: data.full_name,
                        start: data.start_date, 
                        backgroundColor: data.color,
                        tel: data.tel,
                        hour: data.hour,
                        address: data.ddress ,
                        description: data.description,
                        color: data.color
                    }     
                    // $('#calendar').fullCalendar( 'renderEvents' ,recall , true); // add new  recall  to DOM
                    Command: toastr["success"]("L'agenda a étè modifié avec succès !", "Modifier Agenda");
                    //refresh page
                    $('#recallDetails').hide();
                    setTimeout(function() {
                        location.reload();                      
                    }, 2000);
                }
            });

        toastr.options = {
            "closeButton": true,
            "debug": false,
            "newestOnTop": false,
            "progressBar": true,
            "positionClass": "toast-top-right",
            "preventDuplicates": false,
            "onclick": null,
            "showDuration": "1000",
            "hideDuration": "1000",
            "timeOut": "3000",
            "extendedTimeOut": "1000",
            "showEasing": "swing",
            "hideEasing": "swing",
            "showMethod": "show"
            }    
        } else { 
            $('#dateMessageD').text('La date est obligatoire !');
            $("#start-dateD").focus();
            setTimeout(function() {
                $("#dateMessageD").text('');                       
            }, 3000);

        }
        
    });
    
    $("#delete-recall").on('click', function (e) {
        
        e.preventDefault();         
        var recallId = $("#recall-id").val();
        // var fullName = $("#full-nameD").val(); 
        // var startDate = $("#start-dateD").val(); 
        // var backColor = $("#recall-colorD").val();
        // console.log(`${fullName} ${recallColor} ${address} ${tel} ${startDate} ${hour} ${userId}`);
        // create new recall  
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });      
        $.ajax({
            type:"DELETE",
            url:"/delete-recall/" + recallId , 
            success:function() {  
                console.log(recallId);     
                $('#calendar').fullCalendar( 'removeEvents' , recallId ); // remove  recall  to DOM
                Command: toastr["success"]("L'agenda a étè supprimé avec succès !", "Supprimer Agenda");

                toastr.options = {
                    "closeButton": true,
                    "debug": false,
                    "newestOnTop": false,
                    "progressBar": true,
                    "positionClass": "toast-top-right",
                    "preventDuplicates": false,
                    "onclick": null,
                    "showDuration": "1000",
                    "hideDuration": "1000",
                    "timeOut": "3000",
                    "extendedTimeOut": "1000",
                    "showEasing": "swing",
                    "hideEasing": "swing",
                    "showMethod": "show"
                    }
                //refresh page 
            }
        });
        
    });

    $("#close_calendar_event").on('click', function (e) {
        $("#new-event").val("");
    });


    $('input[type="checkbox"].custom_icheck, input[type="radio"].custom_radio').iCheck({
        checkboxClass: 'icheckbox_minimal-blue',
        radioClass: 'iradio_minimal-blue',
        increaseArea: '20%'
    });
 
    $('#refreshCalender').click(function(e){
        var event=[{
            title: 'Team Out',
            start: new Date(y, m, 2),
            end: new Date(y, m, 2),
            backgroundColor: "#f0ad4e"
        }, {
            title: 'Client Meeting',
            start: new Date(y, m, 2),
            end: new Date(y, m, 2), 
            backgroundColor: "#66ccff"
        }, {
            title: 'Repeating Event',
            start: new Date(y, m, 2),
            end: new Date(y, m, 2),
        }, {
            title: 'Birthday Party',
            start: new Date(y, m, 2),
            end: new Date(y, m, 2),
            backgroundColor: "#66cc99"
        }, {
            title: 'Product Seminar',
            start: new Date(y, m, 2),
            end: new Date(y, m, 2),
            backgroundColor: "#dcdcdc"
        }, {
            title: 'Anniversary Celebrations',
            start: new Date(y, m, 2),
            end: new Date(y, m, 2),
            backgroundColor: "#66cc99"
        }, {
            title: 'Client Meeting',
            start: new Date(y, m, 2),
            end: new Date(y, m, 2),
            backgroundColor: "#ff6666"
        }];
        console.log(event);
        $('#calendar').fullCalendar( 'renderEvents', event, true);// addmulti events
        // $('#calendar').fullCalendar( 'renderEvent', event, true); // add one event
        $('#calendar').fullCalendar( 'rerenderEvents' );// refresh data
        e.preventDefault();
    });
    // var events = [];
         

    // $('#calendar').fullCalendar({ 
    //     events: function (start, end, tz, callback) {
    //         callback(events);
    //     }
    // });
    // $.get('/get-recalls',function(recalls) {   
    //     $.each(recalls, function(i, recall){ 
    //         events.push({
    //             title: recall.first_name,
    //             start: recall.start_date
    //         });
    //     })
    // });  
    // $('#calendar').fullCalendar('refetchEvents');

});