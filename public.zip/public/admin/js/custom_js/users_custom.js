'use strict';
$(document).ready(function () {
    $('#table').DataTable({
        "responsive": true
    });
});