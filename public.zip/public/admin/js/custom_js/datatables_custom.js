"use strict";
$(document).ready(function() {

    $('#dataTableUsersAdmin').dataTable({
        "pageLength": 50,
        "responsive": true
    });
    $('#dataTableUsersAgent').dataTable({
        "pageLength": 50,
        "responsive": true
    });

    $('#dataTableUsersCloser').dataTable({
        "pageLength": 50,
        "responsive": true
    });

    $('#dataTableSimple').dataTable({
        "responsive": true
    });
    $('#scriptClosers').dataTable({
        "responsive": true
    });
    $('#scriptAgents').dataTable({
        "responsive": true
    });


    $('#dataTableSheetsList').dataTable({
        "responsive": true,        
        "processing":true,
		"order" :[[0,"asc"]]
    });


    var table = $('#example').DataTable({
        "responsive": true
    });

    $('button.toggle-vis').on('click', function(e) {
        e.preventDefault();

        // Get the column API object
        var column = table.column($(this).attr('data-column'));

        // Toggle the visibility
        column.visible(!column.visible());
    });

});
